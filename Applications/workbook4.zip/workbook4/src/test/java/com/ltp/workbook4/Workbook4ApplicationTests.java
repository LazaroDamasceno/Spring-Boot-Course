package com.ltp.workbook4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Workbook4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
