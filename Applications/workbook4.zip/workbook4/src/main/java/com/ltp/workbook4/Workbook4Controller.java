package com.ltp.workbook4;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Workbook4Controller {
    
    @GetMapping("/")
    public String getSign(Model model) {
        model.addAttribute("speed", 60);
        return "sign";
    }

}
