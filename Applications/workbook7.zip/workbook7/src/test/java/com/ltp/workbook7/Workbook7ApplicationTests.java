package com.ltp.workbook7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Workbook7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
