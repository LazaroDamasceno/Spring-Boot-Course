package com.ltp.workbook11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Workbook11Application {

    public static void main(String[] args) {
        SpringApplication.run(Workbook11Application.class, args);
    }

}
