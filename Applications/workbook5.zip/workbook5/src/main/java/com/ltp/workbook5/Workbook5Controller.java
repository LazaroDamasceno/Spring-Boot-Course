package com.ltp.workbook5;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Workbook5Controller {
    
    @GetMapping("/")
    public String getPainting(Model model) {
        model.addAttribute("painting", "corridor");
        return "painting";
    }

}
