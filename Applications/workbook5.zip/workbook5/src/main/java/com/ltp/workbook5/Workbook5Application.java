package com.ltp.workbook5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Workbook5Application {

	public static void main(String[] args) {
		SpringApplication.run(Workbook5Application.class, args);
	}

}
