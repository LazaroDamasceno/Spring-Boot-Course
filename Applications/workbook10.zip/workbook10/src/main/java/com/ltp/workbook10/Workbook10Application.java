package com.ltp.workbook10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Workbook10Application {

    public static void main(String[] args) {
        SpringApplication.run(Workbook10Application.class, args);
    }

}
