package com.ltp.workbook6;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Workbook6Controller {
    
    @GetMapping("/")
    public String getDealership(Model model) {
        model.addAttribute("budget", 5000);
        model.addAttribute("make", "Toyota");
        return "dealership";
    }

}
