package com.ltp.workbook6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Workbook6Application {

	public static void main(String[] args) {
		SpringApplication.run(Workbook6Application.class, args);
	}

}
