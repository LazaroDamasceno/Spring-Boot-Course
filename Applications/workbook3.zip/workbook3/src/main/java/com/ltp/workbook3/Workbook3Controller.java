package com.ltp.workbook3;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Workbook3Controller {
    
    @GetMapping(value="/")
    public String getSign(Model model) {
        model.addAttribute("speed", 70);
        return "sign";
    }

}
